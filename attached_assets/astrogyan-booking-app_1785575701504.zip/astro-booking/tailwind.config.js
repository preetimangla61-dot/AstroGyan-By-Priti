/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        // AstroGyan token system — deep night sky + warm gold, not a generic template palette
        midnight: "#161233",   // primary background — deep indigo-night
        dusk: "#241C4A",       // secondary surface, cards
        gold: "#C9A227",       // primary accent — celestial gold
        goldLight: "#E8CE6B",  // hover/highlight gold
        rose: "#D98E9B",       // secondary accent — soft rose (marriage/love consultations)
        cream: "#F8F3E7",      // light background / text on dark
        ink: "#2A2440",        // body text on cream
      },
      fontFamily: {
        display: ["var(--font-cormorant)", "serif"],
        body: ["var(--font-inter)", "sans-serif"],
      },
      backgroundImage: {
        constellation: "radial-gradient(circle at 20% 20%, rgba(201,162,39,0.15), transparent 40%), radial-gradient(circle at 80% 60%, rgba(217,142,155,0.12), transparent 45%)",
      },
    },
  },
  plugins: [],
};
