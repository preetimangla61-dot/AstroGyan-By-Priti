// GET /api/qrcode?amount=799&note=Career%20Consultation
// Streams back a PNG containing a scannable UPI deep link QR code.
import QRCode from "qrcode";

export default async function handler(req, res) {
  if (req.method !== "GET") return res.status(405).end();

  const amount = req.query.amount || "0";
  const note = req.query.note || "AstroGyan Consultation";
  const upiId = process.env.NEXT_PUBLIC_UPI_ID || "8607723548@ybl";
  const payeeName = process.env.NEXT_PUBLIC_UPI_PAYEE_NAME || "PreetiManglaAstrology";

  const upiUri =
    `upi://pay?pa=${encodeURIComponent(upiId)}` +
    `&pn=${encodeURIComponent(payeeName)}` +
    `&am=${encodeURIComponent(amount)}` +
    `&cu=INR` +
    `&tn=${encodeURIComponent(note)}`;

  try {
    const buffer = await QRCode.toBuffer(upiUri, {
      width: 320,
      margin: 2,
      color: { dark: "#161233", light: "#F8F3E7" },
    });
    res.setHeader("Content-Type", "image/png");
    res.status(200).send(buffer);
  } catch (err) {
    res.status(500).json({ error: "Could not generate QR code" });
  }
}
