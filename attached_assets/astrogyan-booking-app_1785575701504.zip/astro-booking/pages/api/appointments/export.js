// GET /api/appointments/export -> CSV download of all appointments (admin dashboard)
import { getAllAppointments } from "../../../lib/db";

function toCsvValue(v) {
  const s = String(v ?? "");
  return `"${s.replace(/"/g, '""')}"`;
}

function isAdmin(req) {
  const code = req.headers["x-admin-code"] || req.query.code;
  return Boolean(code) && code === process.env.ADMIN_ACCESS_CODE;
}

export default function handler(req, res) {
  if (req.method !== "GET") return res.status(405).end();
  if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });

  const appointments = getAllAppointments();
  const columns = [
    "id",
    "fullName",
    "email",
    "phone",
    "consultationType",
    "appointmentDate",
    "appointmentTime",
    "amount",
    "status",
    "transactionId",
    "createdAt",
  ];

  const rows = [columns.join(",")];
  for (const a of appointments) {
    rows.push(columns.map((c) => toCsvValue(a[c])).join(","));
  }
  const csv = rows.join("\n");

  res.setHeader("Content-Type", "text/csv");
  res.setHeader(
    "Content-Disposition",
    `attachment; filename="appointments-${new Date().toISOString().slice(0, 10)}.csv"`
  );
  res.status(200).send(csv);
}
