// GET  /api/appointments        -> list all (admin dashboard)
// POST /api/appointments        -> create a new pending appointment (booking form)
import { v4 as uuidv4 } from "uuid";
import {
  createAppointment,
  getAllAppointments,
  isSlotTaken,
} from "../../../lib/db";
import { validateAppointmentInput, sanitize } from "../../../lib/validate";
import { getAmountForType } from "../../../lib/slots";

function isAdmin(req) {
  const code = req.headers["x-admin-code"];
  return Boolean(code) && code === process.env.ADMIN_ACCESS_CODE;
}

export default function handler(req, res) {
  if (req.method === "GET") {
    // Listing all appointments is an admin-only action.
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    return res.status(200).json({ appointments: getAllAppointments() });
  }

  if (req.method === "POST") {
    const errors = validateAppointmentInput(req.body);
    if (errors.length) {
      return res.status(400).json({ errors });
    }

    const {
      fullName,
      email,
      phone,
      dob,
      timeOfBirth,
      placeOfBirth,
      gender,
      consultationType,
      appointmentDate,
      appointmentTime,
      notes,
    } = req.body;

    // Re-check on the server to prevent a race / double-booking, even if
    // the client already filtered the slot list.
    if (isSlotTaken(appointmentDate, appointmentTime)) {
      return res
        .status(409)
        .json({ errors: ["That time slot was just booked. Please pick another."] });
    }

    const appointment = {
      id: uuidv4(),
      fullName: sanitize(fullName),
      email: sanitize(email),
      phone: sanitize(phone),
      dob: sanitize(dob),
      timeOfBirth: sanitize(timeOfBirth),
      placeOfBirth: sanitize(placeOfBirth),
      gender: sanitize(gender),
      consultationType: sanitize(consultationType),
      appointmentDate: sanitize(appointmentDate),
      appointmentTime: sanitize(appointmentTime),
      notes: sanitize(notes || ""),
      amount: getAmountForType(consultationType),
      status: "pending_payment", // pending_payment -> paid -> completed | cancelled
      transactionId: null,
      paidAt: null,
      createdAt: new Date().toISOString(),
    };

    createAppointment(appointment);
    return res.status(201).json({ appointment });
  }

  res.setHeader("Allow", ["GET", "POST"]);
  res.status(405).end();
}
