// GET   /api/appointments/:id     -> fetch one (used by the payment/summary pages)
// PATCH /api/appointments/:id     -> admin: update status (completed / cancelled)
import { getAppointmentById, updateAppointment } from "../../../lib/db";
import { sanitize } from "../../../lib/validate";

const ALLOWED_STATUSES = ["pending_payment", "paid", "completed", "cancelled"];

function isAdmin(req) {
  const code = req.headers["x-admin-code"];
  return Boolean(code) && code === process.env.ADMIN_ACCESS_CODE;
}

export default function handler(req, res) {
  const { id } = req.query;

  if (req.method === "GET") {
    const appointment = getAppointmentById(id);
    if (!appointment) return res.status(404).json({ error: "Not found" });
    return res.status(200).json({ appointment });
  }

  if (req.method === "PATCH") {
    if (!isAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { status } = req.body;
    if (!ALLOWED_STATUSES.includes(status)) {
      return res.status(400).json({ error: "Invalid status" });
    }
    const updated = updateAppointment(id, { status: sanitize(status) });
    if (!updated) return res.status(404).json({ error: "Not found" });
    return res.status(200).json({ appointment: updated });
  }

  res.setHeader("Allow", ["GET", "PATCH"]);
  res.status(405).end();
}
