// GET /api/slots?date=YYYY-MM-DD  -> list of { time, available } for that date
import { getSlotsForDate } from "../../lib/slots";

export default function handler(req, res) {
  if (req.method !== "GET") return res.status(405).end();
  const { date } = req.query;
  if (!date) return res.status(400).json({ error: "date is required" });
  const slots = getSlotsForDate(date);
  res.status(200).json({ slots });
}
