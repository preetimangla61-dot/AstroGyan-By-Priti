// POST /api/payment/verify
// Client submits { appointmentId, transactionId } after paying via UPI.
// We mark the appointment paid and fire both notification emails.
// (For a stricter production setup, verify the UTR against your bank/UPI
// provider's webhook or statement before trusting it — see README.)
import { getAppointmentById, updateAppointment } from "../../../lib/db";
import { sendAdminNotification, sendClientReceipt } from "../../../lib/mailer";
import { sanitize } from "../../../lib/validate";

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  const { appointmentId, transactionId } = req.body;
  if (!appointmentId || !transactionId) {
    return res.status(400).json({ error: "appointmentId and transactionId are required" });
  }

  const appointment = getAppointmentById(appointmentId);
  if (!appointment) return res.status(404).json({ error: "Appointment not found" });

  const updated = updateAppointment(appointmentId, {
    status: "paid",
    transactionId: sanitize(transactionId),
    paidAt: new Date().toISOString(),
  });

  // Email sending failures shouldn't block the user from seeing their
  // confirmation — log and continue rather than throwing.
  try {
    await sendAdminNotification(updated);
    await sendClientReceipt(updated);
  } catch (err) {
    console.error("Email sending failed:", err.message);
  }

  res.status(200).json({ appointment: updated });
}
