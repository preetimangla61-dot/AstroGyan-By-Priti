import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import Head from "next/head";
import Navbar from "../../components/Navbar";
import Footer from "../../components/Footer";

const LABELS = {
  career: "Career",
  marriage: "Marriage & Relationships",
  health: "Health",
  finance: "Finance",
  general: "General Guidance",
};

export default function Summary() {
  const router = useRouter();
  const { id } = router.query;
  const [appointment, setAppointment] = useState(null);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!id) return;
    fetch(`/api/appointments/${id}`)
      .then((r) => {
        if (!r.ok) throw new Error();
        return r.json();
      })
      .then((data) => setAppointment(data.appointment))
      .catch(() => setNotFound(true));
  }, [id]);

  return (
    <div className="min-h-screen">
      <Head>
        <title>Confirm your appointment — AstroGyan</title>
      </Head>
      <Navbar />
      <section className="max-w-xl mx-auto px-6 py-16">
        <h1 className="font-display text-3xl text-goldLight mb-6 text-center">
          Review your appointment
        </h1>

        {notFound && (
          <p className="text-center text-rose">
            We couldn't find that booking. Please start over from the home page.
          </p>
        )}

        {!appointment && !notFound && (
          <p className="text-center text-cream/50">Loading…</p>
        )}

        {appointment && (
          <div className="bg-dusk rounded-2xl p-6 space-y-3">
            <Row label="Name" value={appointment.fullName} />
            <Row label="Email" value={appointment.email} />
            <Row label="Phone" value={appointment.phone} />
            <Row label="Consultation type" value={LABELS[appointment.consultationType]} />
            <Row
              label="Appointment"
              value={`${appointment.appointmentDate} at ${appointment.appointmentTime}`}
            />
            <Row label="Date of birth" value={appointment.dob} />
            <Row label="Time of birth" value={appointment.timeOfBirth} />
            <Row label="Place of birth" value={appointment.placeOfBirth} />
            {appointment.notes && <Row label="Your notes" value={appointment.notes} />}
            <div className="border-t border-white/10 pt-3 flex justify-between items-center">
              <span className="text-cream/70">Amount due</span>
              <span className="text-xl text-goldLight font-semibold">
                ₹{appointment.amount}
              </span>
            </div>

            <button
              onClick={() => router.push(`/booking/payment?id=${appointment.id}`)}
              className="w-full mt-4 rounded-full bg-gold text-midnight font-semibold py-3 hover:bg-goldLight transition"
            >
              Looks good — proceed to payment
            </button>
          </div>
        )}
      </section>
      <Footer />
    </div>
  );
}

function Row({ label, value }) {
  return (
    <div className="flex justify-between gap-4 text-sm">
      <span className="text-cream/50">{label}</span>
      <span className="text-right">{value}</span>
    </div>
  );
}
