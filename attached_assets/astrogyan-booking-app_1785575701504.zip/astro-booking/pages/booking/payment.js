import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import Head from "next/head";
import Navbar from "../../components/Navbar";
import Footer from "../../components/Footer";

export default function Payment() {
  const router = useRouter();
  const { id } = router.query;
  const [appointment, setAppointment] = useState(null);
  const [transactionId, setTransactionId] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [confirmed, setConfirmed] = useState(false);

  const upiId = process.env.NEXT_PUBLIC_UPI_ID || "8607723548@ybl";

  useEffect(() => {
    if (!id) return;
    fetch(`/api/appointments/${id}`)
      .then((r) => r.json())
      .then((data) => setAppointment(data.appointment));
  }, [id]);

  async function handleVerify(e) {
    e.preventDefault();
    setError("");
    if (!transactionId.trim()) {
      setError("Enter the transaction ID / UTR from your UPI app.");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/payment/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ appointmentId: id, transactionId }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Could not verify payment.");
        setSubmitting(false);
        return;
      }
      setAppointment(data.appointment);
      setConfirmed(true);
    } catch (err) {
      setError("Network error — please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  if (!appointment) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <p className="text-center text-cream/50 py-20">Loading…</p>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Head>
        <title>Pay via UPI — AstroGyan</title>
      </Head>
      <Navbar />
      <section className="max-w-md mx-auto px-6 py-16 text-center">
        {!confirmed ? (
          <>
            <h1 className="font-display text-3xl text-goldLight mb-2">Complete your payment</h1>
            <p className="text-cream/70 mb-6">
              Scan the QR code or pay via UPI app using ID{" "}
              <span className="text-goldLight font-medium">{upiId}</span>
            </p>

            <div className="bg-cream rounded-2xl p-4 inline-block mb-6">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={`/api/qrcode?amount=${appointment.amount}&note=${encodeURIComponent(
                  appointment.consultationType + " consultation"
                )}`}
                alt="UPI payment QR code"
                width={240}
                height={240}
              />
            </div>

            <div className="bg-dusk rounded-xl p-4 mb-6 text-sm space-y-1">
              <p>
                <span className="text-cream/50">Pay to UPI ID: </span>
                <span className="text-goldLight">{upiId}</span>
              </p>
              <p>
                <span className="text-cream/50">Amount: </span>
                <span className="text-goldLight">₹{appointment.amount}</span>
              </p>
            </div>

            <form onSubmit={handleVerify} className="space-y-3 text-left">
              <label className="block text-sm text-cream/70">
                Transaction ID / UTR (from your UPI app)
              </label>
              <input
                value={transactionId}
                onChange={(e) => setTransactionId(e.target.value)}
                className="w-full bg-midnight border border-white/10 rounded-lg px-3 py-2 text-cream"
                placeholder="e.g. 349827561234"
              />
              {error && <p className="text-rose text-sm">{error}</p>}
              <button
                type="submit"
                disabled={submitting}
                className="w-full rounded-full bg-gold text-midnight font-semibold py-3 hover:bg-goldLight transition disabled:opacity-40"
              >
                {submitting ? "Verifying…" : "I've paid — confirm booking"}
              </button>
            </form>
          </>
        ) : (
          <div className="bg-dusk rounded-2xl p-8">
            <h1 className="font-display text-3xl text-goldLight mb-3">Booking confirmed 🎉</h1>
            <p className="text-cream/70 mb-4">
              A confirmation email with your receipt has been sent to{" "}
              <span className="text-goldLight">{appointment.email}</span>. See you on{" "}
              {appointment.appointmentDate} at {appointment.appointmentTime}.
            </p>
            <a href="/" className="text-gold underline text-sm">
              Back to home
            </a>
          </div>
        )}
      </section>
      <Footer />
    </div>
  );
}
