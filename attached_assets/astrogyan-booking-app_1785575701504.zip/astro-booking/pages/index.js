import Head from "next/head";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import BookingForm from "../components/BookingForm";
import Testimonials from "../components/Testimonials";
import FAQ from "../components/FAQ";
import ContactSection from "../components/ContactSection";

export default function Home() {
  return (
    <div className="min-h-screen">
      <Head>
        <title>AstroGyan by Preeti Mangla — Book a Consultation</title>
        <meta
          name="description"
          content="Book a Vedic astrology consultation with Preeti Mangla — career, marriage, health, finance and general guidance."
        />
      </Head>

      <Navbar />

      {/* Hero — the thesis: a birth-chart wheel motif behind the headline */}
      <section className="constellation-bg">
        <div className="max-w-5xl mx-auto px-6 pt-20 pb-16 text-center">
          <p className="uppercase tracking-[0.3em] text-xs text-rose mb-4">
            Vedic Astrology &amp; Life Guidance
          </p>
          <h1 className="font-display text-5xl sm:text-6xl leading-tight text-goldLight mb-6">
            Clarity, written in the stars
          </h1>
          <p className="max-w-xl mx-auto text-cream/70 mb-10">
            One-on-one readings with Preeti Mangla — for career crossroads, matters of the
            heart, health, finance, and the questions that keep circling back.
          </p>
          <a
            href="#book"
            className="inline-block rounded-full bg-gold text-midnight font-semibold px-10 py-3 hover:bg-goldLight transition"
          >
            Book your reading
          </a>
        </div>
      </section>

      <section id="book" className="max-w-2xl mx-auto px-6 py-10">
        <h2 className="font-display text-3xl text-goldLight text-center mb-8">
          Book your consultation
        </h2>
        <BookingForm />
      </section>

      <Testimonials />
      <FAQ />
      <ContactSection />
      <Footer />
    </div>
  );
}
