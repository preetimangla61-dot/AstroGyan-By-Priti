import { useEffect, useMemo, useState } from "react";
import Head from "next/head";

const STATUS_LABELS = {
  pending_payment: "Pending payment",
  paid: "Paid",
  completed: "Completed",
  cancelled: "Cancelled",
};

const CONSULTATION_LABELS = {
  career: "Career",
  marriage: "Marriage & Relationships",
  health: "Health",
  finance: "Finance",
  general: "General Guidance",
};

export default function AdminDashboard() {
  const [code, setCode] = useState("");
  const [authed, setAuthed] = useState(false);
  const [appointments, setAppointments] = useState([]);
  const [error, setError] = useState("");
  const [dateFilter, setDateFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");

  useEffect(() => {
    const saved = typeof window !== "undefined" && sessionStorage.getItem("astrogyan_admin_code");
    if (saved) {
      setCode(saved);
      load(saved);
    }
  }, []);

  async function load(accessCode) {
    setError("");
    const res = await fetch("/api/appointments", {
      headers: { "x-admin-code": accessCode },
    });
    if (!res.ok) {
      setError("Incorrect access code.");
      setAuthed(false);
      return;
    }
    const data = await res.json();
    setAppointments(data.appointments);
    setAuthed(true);
    sessionStorage.setItem("astrogyan_admin_code", accessCode);
  }

  async function updateStatus(id, status) {
    await fetch(`/api/appointments/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json", "x-admin-code": code },
      body: JSON.stringify({ status }),
    });
    load(code);
  }

  const filtered = useMemo(() => {
    return appointments.filter((a) => {
      if (dateFilter && a.appointmentDate !== dateFilter) return false;
      if (statusFilter && a.status !== statusFilter) return false;
      if (typeFilter && a.consultationType !== typeFilter) return false;
      return true;
    });
  }, [appointments, dateFilter, statusFilter, typeFilter]);

  if (!authed) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Head>
          <title>Admin — AstroGyan</title>
        </Head>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            load(code);
          }}
          className="bg-dusk rounded-2xl p-8 w-full max-w-sm space-y-4"
        >
          <h1 className="font-display text-2xl text-goldLight text-center">Admin access</h1>
          <input
            type="password"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="Access code"
            className="w-full bg-midnight border border-white/10 rounded-lg px-3 py-2 text-cream"
          />
          {error && <p className="text-rose text-sm">{error}</p>}
          <button className="w-full rounded-full bg-gold text-midnight font-semibold py-2 hover:bg-goldLight transition">
            Enter
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="min-h-screen px-6 py-10 max-w-6xl mx-auto">
      <Head>
        <title>Admin dashboard — AstroGyan</title>
      </Head>
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-display text-3xl text-goldLight">Appointments</h1>
        <a
          href={`/api/appointments/export?code=${encodeURIComponent(code)}`}
          className="text-sm rounded-full border border-gold text-gold px-4 py-2 hover:bg-gold hover:text-midnight transition"
        >
          Export CSV
        </a>
      </div>

      <div className="flex flex-wrap gap-3 mb-6">
        <input
          type="date"
          value={dateFilter}
          onChange={(e) => setDateFilter(e.target.value)}
          className="bg-dusk border border-white/10 rounded-lg px-3 py-2 text-sm"
        />
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="bg-dusk border border-white/10 rounded-lg px-3 py-2 text-sm"
        >
          <option value="">All statuses</option>
          {Object.entries(STATUS_LABELS).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </select>
        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="bg-dusk border border-white/10 rounded-lg px-3 py-2 text-sm"
        >
          <option value="">All consultation types</option>
          {Object.entries(CONSULTATION_LABELS).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </select>
      </div>

      <div className="overflow-x-auto rounded-xl border border-white/10">
        <table className="w-full text-sm">
          <thead className="bg-dusk text-cream/60 text-left">
            <tr>
              <th className="px-4 py-3">Client</th>
              <th className="px-4 py-3">Type</th>
              <th className="px-4 py-3">Appointment</th>
              <th className="px-4 py-3">Amount</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Transaction</th>
              <th className="px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((a) => (
              <tr key={a.id} className="border-t border-white/5">
                <td className="px-4 py-3">
                  <div className="font-medium">{a.fullName}</div>
                  <div className="text-cream/40 text-xs">{a.email} · {a.phone}</div>
                </td>
                <td className="px-4 py-3">{CONSULTATION_LABELS[a.consultationType]}</td>
                <td className="px-4 py-3">
                  {a.appointmentDate} <br /> {a.appointmentTime}
                </td>
                <td className="px-4 py-3">₹{a.amount}</td>
                <td className="px-4 py-3">
                  <span
                    className={`px-2 py-1 rounded-full text-xs ${
                      a.status === "paid"
                        ? "bg-gold/20 text-goldLight"
                        : a.status === "completed"
                        ? "bg-green-500/20 text-green-300"
                        : a.status === "cancelled"
                        ? "bg-rose/20 text-rose"
                        : "bg-white/10 text-cream/60"
                    }`}
                  >
                    {STATUS_LABELS[a.status]}
                  </span>
                </td>
                <td className="px-4 py-3">{a.transactionId || "—"}</td>
                <td className="px-4 py-3 space-x-2 whitespace-nowrap">
                  <button
                    onClick={() => updateStatus(a.id, "completed")}
                    className="text-xs text-green-300 hover:underline"
                  >
                    Mark done
                  </button>
                  <button
                    onClick={() => updateStatus(a.id, "cancelled")}
                    className="text-xs text-rose hover:underline"
                  >
                    Cancel
                  </button>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-8 text-center text-cream/40">
                  No appointments match these filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
