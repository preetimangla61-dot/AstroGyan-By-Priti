import { useState } from "react";

const FAQS = [
  {
    q: "How does the consultation happen?",
    a: "After you book a slot and complete payment, you'll receive a confirmation email and a call/WhatsApp message ahead of your appointment time to connect over call or video.",
  },
  {
    q: "What details do I need to provide?",
    a: "Your accurate date, time, and place of birth are essential for a precise reading. If you don't know your exact birth time, provide your best estimate and mention it in the notes field.",
  },
  {
    q: "How do I pay?",
    a: "Scan the UPI QR code shown after booking, or pay directly to the UPI ID displayed on the payment page. Enter the transaction ID/UTR from your payment app to confirm.",
  },
  {
    q: "Can I reschedule or cancel?",
    a: "Yes — message us on Instagram or call the number in the footer at least 24 hours before your slot and we'll help you find a new time.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState(null);

  return (
    <section id="faq" className="max-w-3xl mx-auto px-6 py-16">
      <h2 className="font-display text-3xl text-goldLight text-center mb-10">
        Frequently asked questions
      </h2>
      <div className="space-y-3">
        {FAQS.map((item, i) => (
          <div key={i} className="border border-white/10 rounded-xl overflow-hidden">
            <button
              onClick={() => setOpen(open === i ? null : i)}
              className="w-full text-left px-5 py-4 flex justify-between items-center bg-dusk hover:bg-dusk/80 transition"
              aria-expanded={open === i}
            >
              <span className="font-medium">{item.q}</span>
              <span className="text-gold">{open === i ? "−" : "+"}</span>
            </button>
            {open === i && (
              <div className="px-5 py-4 text-sm text-cream/70 bg-midnight">{item.a}</div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
