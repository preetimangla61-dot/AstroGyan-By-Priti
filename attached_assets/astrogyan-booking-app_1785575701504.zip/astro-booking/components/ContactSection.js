export default function ContactSection() {
  const contact = process.env.NEXT_PUBLIC_CONTACT_NUMBER || "+917082504021";
  const handle = process.env.NEXT_PUBLIC_INSTAGRAM_HANDLE || "astrogyan_by_priti";

  return (
    <section className="max-w-3xl mx-auto px-6 py-16 text-center">
      <h2 className="font-display text-3xl text-goldLight mb-3">Not ready to book yet?</h2>
      <p className="text-cream/70 mb-8">
        Say hello first — send a message on Instagram or give us a call.
      </p>
      <div className="flex flex-col sm:flex-row justify-center gap-4">
        <a
          href={`tel:${contact}`}
          className="inline-block rounded-full bg-gold text-midnight font-semibold px-8 py-3 hover:bg-goldLight transition"
        >
          Call {contact}
        </a>
        <a
          href={`https://instagram.com/${handle}`}
          target="_blank"
          rel="noreferrer"
          className="inline-block rounded-full border border-rose text-rose font-semibold px-8 py-3 hover:bg-rose hover:text-midnight transition"
        >
          Message on Instagram
        </a>
      </div>
    </section>
  );
}
