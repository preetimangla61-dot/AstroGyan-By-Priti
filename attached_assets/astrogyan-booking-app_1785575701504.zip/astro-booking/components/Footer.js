export default function Footer() {
  const contact = process.env.NEXT_PUBLIC_CONTACT_NUMBER || "+917082504021";
  const handle = process.env.NEXT_PUBLIC_INSTAGRAM_HANDLE || "astrogyan_by_priti";

  return (
    <footer id="contact" className="border-t border-white/10 mt-24">
      <div className="max-w-5xl mx-auto px-6 py-12 grid gap-8 sm:grid-cols-3">
        <div>
          <h3 className="font-display text-xl text-goldLight mb-2">AstroGyan</h3>
          <p className="text-sm text-cream/70">
            Vedic astrology readings by Preeti Mangla — career, marriage, health, finance
            and general life guidance.
          </p>
        </div>
        <div>
          <h4 className="text-sm uppercase tracking-widest text-rose mb-2">Reach us</h4>
          <ul className="space-y-2 text-sm">
            <li>
              <a href={`tel:${contact}`} className="hover:text-goldLight transition">
                📞 {contact}
              </a>
            </li>
            <li>
              <a
                href={`https://instagram.com/${handle}`}
                target="_blank"
                rel="noreferrer"
                className="hover:text-goldLight transition"
              >
                📸 @{handle}
              </a>
            </li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm uppercase tracking-widest text-rose mb-2">Astrologer</h4>
          <a href="/admin" className="text-sm text-cream/50 hover:text-cream transition">
            Admin dashboard
          </a>
        </div>
      </div>
      <div className="text-center text-xs text-cream/40 pb-6">
        © {new Date().getFullYear()} AstroGyan by Preeti Mangla
      </div>
    </footer>
  );
}
