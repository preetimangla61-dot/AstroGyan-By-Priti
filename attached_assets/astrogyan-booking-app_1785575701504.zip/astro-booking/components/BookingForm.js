import { useEffect, useState } from "react";
import { useRouter } from "next/router";

const CONSULTATION_TYPES = [
  { id: "career", label: "Career" },
  { id: "marriage", label: "Marriage & Relationships" },
  { id: "health", label: "Health" },
  { id: "finance", label: "Finance" },
  { id: "general", label: "General Guidance" },
];

const initialForm = {
  fullName: "",
  email: "",
  phone: "",
  dob: "",
  timeOfBirth: "",
  placeOfBirth: "",
  gender: "",
  consultationType: "career",
  appointmentDate: "",
  appointmentTime: "",
  notes: "",
};

export default function BookingForm() {
  const router = useRouter();
  const [form, setForm] = useState(initialForm);
  const [slots, setSlots] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [errors, setErrors] = useState([]);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!form.appointmentDate) {
      setSlots([]);
      return;
    }
    setLoadingSlots(true);
    fetch(`/api/slots?date=${form.appointmentDate}`)
      .then((r) => r.json())
      .then((data) => setSlots(data.slots || []))
      .finally(() => setLoadingSlots(false));
  }, [form.appointmentDate]);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setErrors([]);
    setSubmitting(true);
    try {
      const res = await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        setErrors(data.errors || ["Something went wrong. Please try again."]);
        setSubmitting(false);
        return;
      }
      router.push(`/booking/summary?id=${data.appointment.id}`);
    } catch (err) {
      setErrors(["Network error — please try again."]);
      setSubmitting(false);
    }
  }

  const today = new Date().toISOString().slice(0, 10);

  return (
    <form onSubmit={handleSubmit} className="bg-dusk rounded-2xl p-6 sm:p-8 space-y-5">
      {errors.length > 0 && (
        <div className="bg-rose/10 border border-rose text-rose text-sm rounded-lg p-3">
          <ul className="list-disc pl-5 space-y-1">
            {errors.map((err, i) => (
              <li key={i}>{err}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="grid sm:grid-cols-2 gap-5">
        <Field label="Full name">
          <input
            required
            value={form.fullName}
            onChange={(e) => update("fullName", e.target.value)}
            className="input"
          />
        </Field>
        <Field label="Email">
          <input
            required
            type="email"
            value={form.email}
            onChange={(e) => update("email", e.target.value)}
            className="input"
          />
        </Field>
        <Field label="Phone number">
          <input
            required
            value={form.phone}
            onChange={(e) => update("phone", e.target.value)}
            placeholder="+91XXXXXXXXXX"
            className="input"
          />
        </Field>
        <Field label="Gender">
          <select
            required
            value={form.gender}
            onChange={(e) => update("gender", e.target.value)}
            className="input"
          >
            <option value="">Select</option>
            <option value="female">Female</option>
            <option value="male">Male</option>
            <option value="other">Other / prefer not to say</option>
          </select>
        </Field>
        <Field label="Date of birth">
          <input
            required
            type="date"
            value={form.dob}
            onChange={(e) => update("dob", e.target.value)}
            className="input"
          />
        </Field>
        <Field label="Time of birth">
          <input
            required
            type="time"
            value={form.timeOfBirth}
            onChange={(e) => update("timeOfBirth", e.target.value)}
            className="input"
          />
        </Field>
        <Field label="Place of birth" full>
          <input
            required
            value={form.placeOfBirth}
            onChange={(e) => update("placeOfBirth", e.target.value)}
            placeholder="City, State"
            className="input"
          />
        </Field>
        <Field label="Type of consultation">
          <select
            value={form.consultationType}
            onChange={(e) => update("consultationType", e.target.value)}
            className="input"
          >
            {CONSULTATION_TYPES.map((c) => (
              <option key={c.id} value={c.id}>
                {c.label}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Preferred appointment date">
          <input
            required
            type="date"
            min={today}
            value={form.appointmentDate}
            onChange={(e) => {
              update("appointmentDate", e.target.value);
              update("appointmentTime", "");
            }}
            className="input"
          />
        </Field>
      </div>

      <div>
        <label className="block text-sm text-cream/70 mb-2">Preferred time slot</label>
        {!form.appointmentDate && (
          <p className="text-sm text-cream/40">Pick a date to see available slots.</p>
        )}
        {loadingSlots && <p className="text-sm text-cream/40">Loading slots…</p>}
        {!loadingSlots && form.appointmentDate && slots.length === 0 && (
          <p className="text-sm text-rose">No slots available that day — try another date.</p>
        )}
        <div className="flex flex-wrap gap-2">
          {slots.map((s) => (
            <button
              type="button"
              key={s.time}
              disabled={!s.available}
              onClick={() => update("appointmentTime", s.time)}
              className={`px-4 py-2 rounded-full text-sm border transition
                ${!s.available ? "border-white/10 text-cream/20 cursor-not-allowed" : ""}
                ${
                  s.available && form.appointmentTime === s.time
                    ? "bg-gold text-midnight border-gold"
                    : s.available
                    ? "border-gold/50 text-gold hover:bg-gold/10"
                    : ""
                }`}
            >
              {s.time}
            </button>
          ))}
        </div>
      </div>

      <Field label="Any specific questions or issues?" full>
        <textarea
          rows={3}
          value={form.notes}
          onChange={(e) => update("notes", e.target.value)}
          className="input"
        />
      </Field>

      <button
        type="submit"
        disabled={submitting || !form.appointmentTime}
        className="w-full rounded-full bg-gold text-midnight font-semibold py-3 hover:bg-goldLight transition disabled:opacity-40 disabled:cursor-not-allowed"
      >
        {submitting ? "Booking…" : "Review & continue to payment"}
      </button>

      <style jsx>{`
        .input {
          width: 100%;
          background: #161233;
          border: 1px solid rgba(255, 255, 255, 0.12);
          border-radius: 0.75rem;
          padding: 0.6rem 0.9rem;
          color: #f8f3e7;
        }
      `}</style>
    </form>
  );
}

function Field({ label, children, full }) {
  return (
    <div className={full ? "sm:col-span-2" : ""}>
      <label className="block text-sm text-cream/70 mb-1">{label}</label>
      {children}
    </div>
  );
}
