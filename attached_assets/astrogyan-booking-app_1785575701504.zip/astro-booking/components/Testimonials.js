const PLACEHOLDER_TESTIMONIALS = [
  {
    name: "Client testimonial coming soon",
    text: "Add your first client review here once you have one — real words from a real reading carry far more weight than generic praise.",
  },
  {
    name: "Client testimonial coming soon",
    text: "This spot is reserved for a second testimonial. Swap in a short quote and the client's first name/initial.",
  },
  {
    name: "Client testimonial coming soon",
    text: "A third testimonial slot — keep these short (2–3 sentences) so they're easy to scan.",
  },
];

export default function Testimonials() {
  return (
    <section className="max-w-5xl mx-auto px-6 py-16">
      <h2 className="font-display text-3xl text-goldLight text-center mb-10">
        What clients say
      </h2>
      <div className="grid sm:grid-cols-3 gap-6">
        {PLACEHOLDER_TESTIMONIALS.map((t, i) => (
          <div key={i} className="bg-dusk rounded-2xl p-6 border border-white/5">
            <p className="text-sm text-cream/80 italic mb-4">"{t.text}"</p>
            <p className="text-xs text-rose">{t.name}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
