import Link from "next/link";

export default function Navbar() {
  return (
    <header className="border-b border-white/10">
      <nav className="max-w-5xl mx-auto flex items-center justify-between px-6 py-5">
        <Link href="/" className="font-display text-2xl tracking-wide text-goldLight">
          AstroGyan
        </Link>
        <div className="flex items-center gap-6 text-sm">
          <a href="#book" className="hover:text-goldLight transition">Book a reading</a>
          <a href="#faq" className="hover:text-goldLight transition">FAQ</a>
          <a href="#contact" className="hover:text-goldLight transition">Contact</a>
        </div>
      </nav>
    </header>
  );
}
