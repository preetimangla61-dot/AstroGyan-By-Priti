# AstroGyan — Appointment Booking App (Preeti Mangla)

A Next.js application for booking astrology consultations, with UPI payment
(QR code + UTR verification), automatic email notifications, an admin
dashboard, and Instagram/contact details throughout.

## Features

- **Booking form** — name, email, phone, DOB, time & place of birth, gender,
  consultation type (Career / Marriage / Health / Finance / General), and a
  live slot picker that prevents double-booking.
- **Summary page** — review everything before paying.
- **UPI payment page** — shows the UPI ID, a scannable QR code generated
  server-side from the `upi://pay` deep link, and a field to submit the
  transaction ID/UTR.
- **Email notifications** — on payment verification, one email goes to the
  astrologer's inbox with full client + payment details, and a confirmation
  receipt email goes to the client.
- **Admin dashboard** (`/admin`) — access-code protected; view, filter (by
  date / status / consultation type), mark completed/cancelled, and export
  to CSV.
- **Spiritual, mobile-responsive design** — deep indigo/gold palette,
  Cormorant Garamond display type + Inter body type.

## Tech stack

- **Frontend + backend:** Next.js (React) with API routes — one project,
  no separate server needed.
- **Data store:** a JSON file (`data/db.json`) for zero-setup local
  development — see "Moving to a real database" below before going live.
- **Email:** Nodemailer over SMTP.
- **QR code:** the `qrcode` package, rendered server-side at `/api/qrcode`.

## Project structure

```
astro-booking/
├── components/         Navbar, Footer, BookingForm, Testimonials, FAQ, ContactSection
├── data/db.json         JSON data store (appointments + availability)
├── lib/                 db.js, mailer.js, slots.js, validate.js
├── pages/
│   ├── index.js         Landing page + booking form
│   ├── booking/
│   │   ├── summary.js    Review-before-payment page
│   │   └── payment.js    UPI QR + UTR verification
│   ├── admin/index.js    Admin dashboard
│   └── api/
│       ├── slots.js
│       ├── qrcode.js
│       ├── appointments/{index,[id],export}.js
│       └── payment/verify.js
├── styles/globals.css
├── .env.example
└── package.json
```

## Setup — run locally

1. **Install dependencies** (requires Node.js 18+):
   ```bash
   npm install
   ```
2. **Configure environment variables:**
   ```bash
   cp .env.example .env.local
   ```
   Then edit `.env.local`:
   - `SMTP_USER` / `SMTP_PASS`: for Gmail, turn on 2-Step Verification, then
     create an **App Password** at
     https://myaccount.google.com/apppasswords and use that (not your normal
     password).
   - `ADMIN_ACCESS_CODE`: pick a private code to gate `/admin`.
   - The UPI ID, payee name, contact number, and Instagram handle are already
     filled in with the business details provided; change them here if they
     ever change.
3. **Run the dev server:**
   ```bash
   npm run dev
   ```
   Visit http://localhost:3000. The admin dashboard is at
   http://localhost:3000/admin.

## Setting availability

Admin-configurable availability lives in `data/db.json` under
`"availability"` (working days, start/end hour, slot length, blocked dates).
For a quick edit, change that JSON directly; for a friendlier admin UI, add
a small settings form in `pages/admin/index.js` that calls a new
`/api/availability` route backed by `setAvailability()` in `lib/db.js`
(the function already exists, it's just not wired to a UI yet).

## Moving to a real database

`data/db.json` is intentionally simple so the app runs with no setup — but
serverless hosts (Vercel, Netlify) have a **read-only, ephemeral**
filesystem, so writes won't persist once deployed. Before going live:

1. Provision PostgreSQL (e.g. Neon, Supabase, Render) or MongoDB (e.g. Atlas).
2. Replace the functions in `lib/db.js` (`getAllAppointments`,
   `createAppointment`, `updateAppointment`, `isSlotTaken`, etc.) with real
   queries. Every other file only calls these functions, so this is a
   contained change.
3. For Postgres, a minimal schema:
   ```sql
   create table appointments (
     id uuid primary key,
     full_name text, email text, phone text,
     dob date, time_of_birth text, place_of_birth text, gender text,
     consultation_type text, appointment_date date, appointment_time text,
     notes text, amount integer,
     status text default 'pending_payment',
     transaction_id text, paid_at timestamptz,
     created_at timestamptz default now()
   );
   ```

## Deployment

- **Frontend + API routes together:** deploy the whole Next.js app to
  **Vercel** (recommended — zero config) or **Render**.
  ```bash
  npm run build
  npm start
  ```
- Set all variables from `.env.example` in your host's environment variable
  settings (never commit `.env.local`).
- Once you've moved to a real database (above), deployment needs no other
  changes — the API routes stay the same.

## Security notes already built in

- All form input is validated and sanitized server-side
  (`lib/validate.js`) before being stored or emailed.
- The server re-checks slot availability on submit to prevent race-condition
  double-bookings, not just relying on the client's slot list.
- `/admin`'s data-listing, status-update, and CSV-export endpoints require
  an `x-admin-code` header matching `ADMIN_ACCESS_CODE` — treat that value
  like a password.
- Deploy behind HTTPS (Vercel/Render/Netlify do this by default) so form
  data and the admin code aren't sent in the clear.
- The current payment "verification" trusts the UTR the client types in.
  For stricter verification before marking a booking paid, connect a UPI
  provider's payment-status API or webhook (e.g. Razorpay, Cashfree, or your
  bank's UPI intent callback) and check the transaction there instead of
  taking the UTR at face value.

## Customizing pricing

Consultation prices live in `lib/slots.js` (`CONSULTATION_TYPES`) — edit the
`amount` for each type there.
